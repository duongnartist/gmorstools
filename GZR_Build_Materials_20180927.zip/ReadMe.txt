GZR_Enterprise_Certificates.p12: Certificates cho cả Dev và Distribution. Password: "1 dấu cách".
GZR_Enterprise_AppID_Dev_Profile.mobileprovision: Profile cho Dev (chạy Debug), cho các app cần dùng Push Notification. Bundle ID: "gzr.bsd.dev".
GZR_Enterprise_AppID_InHouse_Profile.mobileprovision: Profile cho Distribution (install lên máy, bao gồm cả máy KH không cần đăng ký UDID), cho các app cần dùng Push Notification. Bundle ID: "gzr.bsd.dev".
GZR_Enterprise_Wildcard_Dev_Profile.mobileprovision: Profile cho Dev (chạy Debug), cho tất cả các app (không phân biệt Bundle ID - 1 số dịch vụ của Apple như Push notification không dùng được).
GZR_Enterprise_Wildcard_InHouse_Profile.mobileprovision Profile cho Distribution (install lên máy, bao gồm cả máy KH không cần đăng ký UDID), cho tất cả các app (không phân biệt Bundle ID - 1 số dịch vụ của Apple như Push notification không dùng được).
